#!/bin/bash

echo "=== P2P Payment System API Test ==="
echo

# Base URL
BASE_URL="http://localhost:8080"

echo "1. Testing Registration..."
REGISTER_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "password": "password123",
    "displayName": "John Doe",
    "email": "john@example.com",
    "phoneNumber": "1234567890",
    "profilePictureUrl": "https://example.com/avatar.jpg"
  }')

echo "Registration Response: $REGISTER_RESPONSE"
echo

# Extract token from registration response
TOKEN=$(echo $REGISTER_RESPONSE | grep -o '"token":"[^"]*' | grep -o '[^"]*$')

if [ -n "$TOKEN" ]; then
    echo "✅ Registration successful! Token: ${TOKEN:0:20}..."
    echo
    
    echo "2. Testing Profile Access..."
    PROFILE_RESPONSE=$(curl -s -X GET "$BASE_URL/api/users/profile" \
      -H "Authorization: Bearer $TOKEN")
    echo "Profile Response: $PROFILE_RESPONSE"
    echo
    
    echo "3. Testing Badges..."
    BADGES_RESPONSE=$(curl -s -X GET "$BASE_URL/api/badges" \
      -H "Authorization: Bearer $TOKEN")
    echo "Badges Response: $BADGES_RESPONSE"
    echo
    
    echo "4. Testing Transactions..."
    TRANSACTIONS_RESPONSE=$(curl -s -X GET "$BASE_URL/api/transactions" \
      -H "Authorization: Bearer $TOKEN")
    echo "Transactions Response: $TRANSACTIONS_RESPONSE"
    echo
    
else
    echo "❌ Registration failed!"
fi

echo "=== Test Complete ==="