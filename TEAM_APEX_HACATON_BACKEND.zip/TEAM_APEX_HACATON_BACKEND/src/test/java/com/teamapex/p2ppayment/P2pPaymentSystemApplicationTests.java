package com.teamapex.p2ppayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2pPaymentSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}