package com.teamapex.p2ppayment.repository;

import com.teamapex.p2ppayment.entity.Badge;
import com.teamapex.p2ppayment.entity.BadgeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BadgeRepository extends JpaRepository<Badge, Long> {
    
    Optional<Badge> findByName(String name);
    
    List<Badge> findByType(BadgeType type);
    
    List<Badge> findByPointsRequiredLessThanEqualOrderByPointsRequiredAsc(Integer points);
}