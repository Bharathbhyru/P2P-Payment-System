package com.teamapex.p2ppayment.entity;

public enum TransactionType {
    DEBIT,
    CREDIT
}