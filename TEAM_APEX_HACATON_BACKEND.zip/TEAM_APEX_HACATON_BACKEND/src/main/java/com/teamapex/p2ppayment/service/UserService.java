package com.teamapex.p2ppayment.service;

import com.teamapex.p2ppayment.dto.request.UpdateProfileRequest;
import com.teamapex.p2ppayment.dto.response.UserProfileResponse;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.repository.UserRepository;
import com.teamapex.p2ppayment.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        return userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public UserProfileResponse getUserProfile() {
        User user = getCurrentUser();
        return new UserProfileResponse(
                user.getId(),
                user.getUsername(),
                user.getDisplayName(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getProfilePictureUrl(),
                user.getBalance(),
                user.getTotalPoints(),
                user.getCreatedAt()
        );
    }

    @Transactional
    public UserProfileResponse updateUserProfile(UpdateProfileRequest request) {
        User user = getCurrentUser();
        
        if (request.getDisplayName() != null && !request.getDisplayName().trim().isEmpty()) {
            user.setDisplayName(request.getDisplayName());
        }
        
        if (request.getProfilePictureUrl() != null) {
            user.setProfilePictureUrl(request.getProfilePictureUrl());
        }
        
        User updatedUser = userRepository.save(user);
        
        return new UserProfileResponse(
                updatedUser.getId(),
                updatedUser.getUsername(),
                updatedUser.getDisplayName(),
                updatedUser.getEmail(),
                updatedUser.getPhoneNumber(),
                updatedUser.getProfilePictureUrl(),
                updatedUser.getBalance(),
                updatedUser.getTotalPoints(),
                updatedUser.getCreatedAt()
        );
    }

    public List<User> searchUsers(String query) {
        return userRepository.searchUsers(query);
    }

    public User findUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }
}