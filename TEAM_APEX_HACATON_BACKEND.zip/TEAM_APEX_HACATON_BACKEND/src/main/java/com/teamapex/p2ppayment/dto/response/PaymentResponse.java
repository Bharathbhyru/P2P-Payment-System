package com.teamapex.p2ppayment.dto.response;

public class PaymentResponse {
    
    private String message;
    private String transactionReference;
    private boolean success;
    
    // Constructors
    public PaymentResponse() {}
    
    public PaymentResponse(String message, String transactionReference, boolean success) {
        this.message = message;
        this.transactionReference = transactionReference;
        this.success = success;
    }
    
    // Getters and Setters
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getTransactionReference() {
        return transactionReference;
    }
    
    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
}