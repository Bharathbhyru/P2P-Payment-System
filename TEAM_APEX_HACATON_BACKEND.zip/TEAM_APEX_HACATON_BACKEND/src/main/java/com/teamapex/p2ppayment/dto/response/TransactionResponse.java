package com.teamapex.p2ppayment.dto.response;

import com.teamapex.p2ppayment.entity.TransactionCategory;
import com.teamapex.p2ppayment.entity.TransactionStatus;
import com.teamapex.p2ppayment.entity.TransactionType;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionResponse {
    
    private Long id;
    private Long userId;
    private String userDisplayName;
    private Long relatedUserId;
    private String relatedUserDisplayName;
    private BigDecimal amount;
    private TransactionType type;
    private TransactionStatus status;
    private String notes;
    private TransactionCategory category;
    private String transactionReference;
    private LocalDateTime createdAt;
    
    // Constructors
    public TransactionResponse() {}
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public String getUserDisplayName() {
        return userDisplayName;
    }
    
    public void setUserDisplayName(String userDisplayName) {
        this.userDisplayName = userDisplayName;
    }
    
    public Long getRelatedUserId() {
        return relatedUserId;
    }
    
    public void setRelatedUserId(Long relatedUserId) {
        this.relatedUserId = relatedUserId;
    }
    
    public String getRelatedUserDisplayName() {
        return relatedUserDisplayName;
    }
    
    public void setRelatedUserDisplayName(String relatedUserDisplayName) {
        this.relatedUserDisplayName = relatedUserDisplayName;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    public TransactionType getType() {
        return type;
    }
    
    public void setType(TransactionType type) {
        this.type = type;
    }
    
    public TransactionStatus getStatus() {
        return status;
    }
    
    public void setStatus(TransactionStatus status) {
        this.status = status;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    public TransactionCategory getCategory() {
        return category;
    }
    
    public void setCategory(TransactionCategory category) {
        this.category = category;
    }
    
    public String getTransactionReference() {
        return transactionReference;
    }
    
    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}