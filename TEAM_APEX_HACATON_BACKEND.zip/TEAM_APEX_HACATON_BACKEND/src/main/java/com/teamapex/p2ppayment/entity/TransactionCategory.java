package com.teamapex.p2ppayment.entity;

public enum TransactionCategory {
    FOOD_DINING,
    TRANSPORT,
    ENTERTAINMENT,
    BILLS_UTILITIES,
    SHOPPING,
    HEALTHCARE,
    EDUCATION,
    TRAVEL,
    GROCERIES,
    FRIENDS_FAMILY,
    BUSINESS,
    OTHERS
}