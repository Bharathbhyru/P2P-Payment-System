package com.teamapex.p2ppayment.dto.request;

public class UpdateProfileRequest {
    
    private String displayName;
    private String profilePictureUrl;
    
    // Constructors
    public UpdateProfileRequest() {}
    
    public UpdateProfileRequest(String displayName, String profilePictureUrl) {
        this.displayName = displayName;
        this.profilePictureUrl = profilePictureUrl;
    }
    
    // Getters and Setters
    public String getDisplayName() {
        return displayName;
    }
    
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    public String getProfilePictureUrl() {
        return profilePictureUrl;
    }
    
    public void setProfilePictureUrl(String profilePictureUrl) {
        this.profilePictureUrl = profilePictureUrl;
    }
}