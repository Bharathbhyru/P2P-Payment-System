package com.teamapex.p2ppayment.controller;

import com.teamapex.p2ppayment.dto.request.PaymentRequest;
import com.teamapex.p2ppayment.dto.response.PaymentResponse;
import com.teamapex.p2ppayment.dto.response.TransactionResponse;
import com.teamapex.p2ppayment.entity.TransactionCategory;
import com.teamapex.p2ppayment.entity.TransactionType;
import com.teamapex.p2ppayment.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/payments")
    public ResponseEntity<PaymentResponse> processPayment(@Valid @RequestBody PaymentRequest paymentRequest) {
        try {
            PaymentResponse response = paymentService.processPayment(paymentRequest);
            if (response.isSuccess()) {
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest().body(response);
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new PaymentResponse("Payment failed: " + e.getMessage(), null, false));
        }
    }

    @GetMapping("/transactions")
    public ResponseEntity<List<TransactionResponse>> getUserTransactions(
            @RequestParam(required = false) TransactionCategory category,
            @RequestParam(required = false) TransactionType type) {
        try {
            List<TransactionResponse> transactions = paymentService.getUserTransactions(category, type);
            return ResponseEntity.ok(transactions);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/transactions/{transactionReference}")
    public ResponseEntity<TransactionResponse> getTransactionByReference(
            @PathVariable String transactionReference) {
        try {
            TransactionResponse transaction = paymentService.getTransactionByReference(transactionReference);
            return ResponseEntity.ok(transaction);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}