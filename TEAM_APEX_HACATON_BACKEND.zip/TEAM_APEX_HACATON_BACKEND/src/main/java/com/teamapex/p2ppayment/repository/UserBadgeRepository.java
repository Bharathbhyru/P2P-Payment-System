package com.teamapex.p2ppayment.repository;

import com.teamapex.p2ppayment.entity.Badge;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.entity.UserBadge;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserBadgeRepository extends JpaRepository<UserBadge, Long> {
    
    List<UserBadge> findByUserOrderByEarnedAtDesc(User user);
    
    Optional<UserBadge> findByUserAndBadge(User user, Badge badge);
    
    boolean existsByUserAndBadge(User user, Badge badge);
}