package com.teamapex.p2ppayment.controller;

import com.teamapex.p2ppayment.dto.request.UpdateProfileRequest;
import com.teamapex.p2ppayment.dto.response.UserProfileResponse;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/profile")
    public ResponseEntity<UserProfileResponse> getUserProfile() {
        try {
            UserProfileResponse profile = userService.getUserProfile();
            return ResponseEntity.ok(profile);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/profile")
    public ResponseEntity<UserProfileResponse> updateUserProfile(@RequestBody UpdateProfileRequest request) {
        try {
            UserProfileResponse updatedProfile = userService.updateUserProfile(request);
            return ResponseEntity.ok(updatedProfile);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/search")
    public ResponseEntity<List<UserProfileResponse>> searchUsers(@RequestParam String query) {
        try {
            List<User> users = userService.searchUsers(query);
            List<UserProfileResponse> userResponses = users.stream()
                .map(user -> new UserProfileResponse(
                    user.getId(),
                    user.getUsername(),
                    user.getDisplayName(),
                    user.getEmail(),
                    user.getPhoneNumber(),
                    user.getProfilePictureUrl(),
                    null, // Don't expose balance in search
                    null, // Don't expose points in search
                    user.getCreatedAt()
                ))
                .collect(Collectors.toList());
            return ResponseEntity.ok(userResponses);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}