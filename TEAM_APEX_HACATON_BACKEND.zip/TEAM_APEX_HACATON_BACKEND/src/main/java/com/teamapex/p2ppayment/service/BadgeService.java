package com.teamapex.p2ppayment.service;

import com.teamapex.p2ppayment.dto.response.BadgeResponse;
import com.teamapex.p2ppayment.entity.Badge;
import com.teamapex.p2ppayment.entity.BadgeType;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.entity.UserBadge;
import com.teamapex.p2ppayment.repository.BadgeRepository;
import com.teamapex.p2ppayment.repository.TransactionRepository;
import com.teamapex.p2ppayment.repository.UserBadgeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class BadgeService {

    @Autowired
    private BadgeRepository badgeRepository;

    @Autowired
    private UserBadgeRepository userBadgeRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional
    public void initializeDefaultBadges() {
        if (badgeRepository.count() == 0) {
            List<Badge> defaultBadges = new ArrayList<>();
            
            defaultBadges.add(new Badge("Welcome", "Welcome to P2P Payment System!", 
                                      "🎉", 0, BadgeType.MILESTONE));
            defaultBadges.add(new Badge("First Payment", "Made your first payment", 
                                      "💳", 10, BadgeType.ACHIEVEMENT));
            defaultBadges.add(new Badge("Payment Pro", "Made 10 payments", 
                                      "⭐", 100, BadgeType.ACHIEVEMENT));
            defaultBadges.add(new Badge("Transaction Master", "Made 50 payments", 
                                      "🏆", 500, BadgeType.ACHIEVEMENT));
            defaultBadges.add(new Badge("Streak Starter", "Made payments for 3 consecutive days", 
                                      "🔥", 30, BadgeType.STREAK));
            defaultBadges.add(new Badge("Social Butterfly", "Sent money to 5 different people", 
                                      "🦋", 50, BadgeType.SPECIAL));
            
            badgeRepository.saveAll(defaultBadges);
        }
    }

    @Transactional
    public void checkAndAwardBadges(User user) {
        // Award welcome badge for new users
        Badge welcomeBadge = badgeRepository.findByName("Welcome").orElse(null);
        if (welcomeBadge != null && !userBadgeRepository.existsByUserAndBadge(user, welcomeBadge)) {
            userBadgeRepository.save(new UserBadge(user, welcomeBadge));
        }

        // Check transaction-based badges
        Long debitTransactionCount = transactionRepository.countDebitTransactionsByUser(user);
        
        // First Payment badge
        if (debitTransactionCount >= 1) {
            awardBadgeIfNotExists(user, "First Payment");
        }
        
        // Payment Pro badge
        if (debitTransactionCount >= 10) {
            awardBadgeIfNotExists(user, "Payment Pro");
        }
        
        // Transaction Master badge
        if (debitTransactionCount >= 50) {
            awardBadgeIfNotExists(user, "Transaction Master");
        }
    }

    private void awardBadgeIfNotExists(User user, String badgeName) {
        Badge badge = badgeRepository.findByName(badgeName).orElse(null);
        if (badge != null && !userBadgeRepository.existsByUserAndBadge(user, badge)) {
            userBadgeRepository.save(new UserBadge(user, badge));
        }
    }

    public List<BadgeResponse> getUserBadges(User user) {
        List<UserBadge> userBadges = userBadgeRepository.findByUserOrderByEarnedAtDesc(user);
        List<BadgeResponse> badgeResponses = new ArrayList<>();
        
        for (UserBadge userBadge : userBadges) {
            Badge badge = userBadge.getBadge();
            BadgeResponse response = new BadgeResponse(
                badge.getId(),
                badge.getName(),
                badge.getDescription(),
                badge.getIconUrl(),
                badge.getPointsRequired(),
                badge.getType(),
                userBadge.getEarnedAt()
            );
            badgeResponses.add(response);
        }
        
        return badgeResponses;
    }
}