package com.teamapex.p2ppayment.config;

import com.teamapex.p2ppayment.service.BadgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private BadgeService badgeService;

    @Override
    public void run(String... args) throws Exception {
        // Initialize default badges on application startup
        badgeService.initializeDefaultBadges();
    }
}