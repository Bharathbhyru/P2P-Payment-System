package com.teamapex.p2ppayment.controller;

import com.teamapex.p2ppayment.dto.request.LoginRequest;
import com.teamapex.p2ppayment.dto.request.RegisterRequest;
import com.teamapex.p2ppayment.dto.response.AuthResponse;
import com.teamapex.p2ppayment.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            AuthResponse authResponse = authService.authenticateUser(loginRequest);
            if (authResponse.getToken() != null) {
                return ResponseEntity.ok(authResponse);
            } else {
                return ResponseEntity.badRequest().body(authResponse);
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new AuthResponse(null, null, null, "Login failed: " + e.getMessage()));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registerUser(@Valid @RequestBody RegisterRequest registerRequest) {
        try {
            AuthResponse authResponse = authService.registerUser(registerRequest);
            if (authResponse.getToken() != null) {
                return ResponseEntity.ok(authResponse);
            } else {
                return ResponseEntity.badRequest().body(authResponse);
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(new AuthResponse(null, null, null, "Registration failed: " + e.getMessage()));
        }
    }
}