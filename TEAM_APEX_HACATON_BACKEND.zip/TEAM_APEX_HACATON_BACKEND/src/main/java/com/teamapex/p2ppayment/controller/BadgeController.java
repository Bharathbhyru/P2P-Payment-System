package com.teamapex.p2ppayment.controller;

import com.teamapex.p2ppayment.dto.response.BadgeResponse;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.service.BadgeService;
import com.teamapex.p2ppayment.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api")
public class BadgeController {

    @Autowired
    private BadgeService badgeService;

    @Autowired
    private UserService userService;

    @GetMapping("/badges")
    public ResponseEntity<List<BadgeResponse>> getUserBadges() {
        try {
            User user = userService.getCurrentUser();
            List<BadgeResponse> badges = badgeService.getUserBadges(user);
            return ResponseEntity.ok(badges);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}