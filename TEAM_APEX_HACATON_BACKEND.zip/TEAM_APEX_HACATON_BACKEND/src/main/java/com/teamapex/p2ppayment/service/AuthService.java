package com.teamapex.p2ppayment.service;

import com.teamapex.p2ppayment.dto.request.LoginRequest;
import com.teamapex.p2ppayment.dto.request.RegisterRequest;
import com.teamapex.p2ppayment.dto.response.AuthResponse;
import com.teamapex.p2ppayment.entity.User;
import com.teamapex.p2ppayment.repository.UserRepository;
import com.teamapex.p2ppayment.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class AuthService {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    BadgeService badgeService;

    public AuthResponse registerUser(RegisterRequest registerRequest) {
        if (userRepository.existsByUsername(registerRequest.getUsername())) {
            return new AuthResponse(null, null, null, "Error: Username is already taken!");
        }

        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            return new AuthResponse(null, null, null, "Error: Email is already in use!");
        }

        // Create new user's account
        User user = new User(registerRequest.getUsername(),
                           encoder.encode(registerRequest.getPassword()),
                           registerRequest.getDisplayName(),
                           registerRequest.getEmail(),
                           registerRequest.getPhoneNumber());

        user.setProfilePictureUrl(registerRequest.getProfilePictureUrl());
        user.setBalance(new BigDecimal("1000.00")); // Starting balance for new users

        User savedUser = userRepository.save(user);

        // Initialize badges for new user
        badgeService.initializeDefaultBadges();
        badgeService.checkAndAwardBadges(savedUser);

        String jwt = jwtUtils.generateJwtToken(savedUser.getUsername());

        return new AuthResponse(jwt, savedUser.getUsername(), savedUser.getDisplayName(),
                              "User registered successfully!");
    }

    public AuthResponse authenticateUser(LoginRequest loginRequest) {
        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtils.generateJwtToken(loginRequest.getUsername());

        User user = userRepository.findByUsername(loginRequest.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        return new AuthResponse(jwt, user.getUsername(), user.getDisplayName(),
                              "User logged in successfully!");
    }
}