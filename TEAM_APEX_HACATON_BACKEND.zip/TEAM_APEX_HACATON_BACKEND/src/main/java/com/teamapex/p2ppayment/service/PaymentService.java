package com.teamapex.p2ppayment.service;

import com.teamapex.p2ppayment.dto.request.PaymentRequest;
import com.teamapex.p2ppayment.dto.response.PaymentResponse;
import com.teamapex.p2ppayment.dto.response.TransactionResponse;
import com.teamapex.p2ppayment.entity.*;
import com.teamapex.p2ppayment.repository.TransactionRepository;
import com.teamapex.p2ppayment.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class PaymentService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private BadgeService badgeService;

    @Transactional
    public PaymentResponse processPayment(PaymentRequest paymentRequest) {
        try {
            User sender = userService.getCurrentUser();
            User recipient = userService.findUserById(paymentRequest.getRecipientId());

            // Validate payment
            if (sender.getId().equals(recipient.getId())) {
                return new PaymentResponse("Cannot send money to yourself", null, false);
            }

            if (paymentRequest.getAmount() == null) {
                return new PaymentResponse("Invalid amount", null, false);
            }

            if (sender.getBalance().compareTo(paymentRequest.getAmount()) < 0) {
                return new PaymentResponse("Insufficient balance", null, false);
            }

            if (paymentRequest.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
                return new PaymentResponse("Invalid amount", null, false);
            }

            // Generate transaction reference
            String transactionReference = "TXN" + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();

            // Update balances
            sender.setBalance(sender.getBalance().subtract(paymentRequest.getAmount()));
            recipient.setBalance(recipient.getBalance().add(paymentRequest.getAmount()));

            // Create debit transaction for sender
            Transaction debitTransaction = new Transaction(
                    sender,
                    recipient,
                    paymentRequest.getAmount(),
                    TransactionType.DEBIT,
            paymentRequest.getNotes(),
            paymentRequest.getCategory() != null ? paymentRequest.getCategory() : TransactionCategory.OTHERS,
                    transactionReference
            );

            // Create credit transaction for recipient
            Transaction creditTransaction = new Transaction(
                    recipient,
                    sender,
                    paymentRequest.getAmount(),
                    TransactionType.CREDIT,
            paymentRequest.getNotes(),
            paymentRequest.getCategory() != null ? paymentRequest.getCategory() : TransactionCategory.OTHERS,
                    transactionReference
            );

        // Save transactions first and flush to surface DB errors early
        transactionRepository.save(debitTransaction);
        transactionRepository.save(creditTransaction);
        transactionRepository.flush();

            // Award points for the transaction
            sender.setTotalPoints(sender.getTotalPoints() + 1);
            recipient.setTotalPoints(recipient.getTotalPoints() + 1);
            
            // Save users with updated balances and points
            userRepository.save(sender);
            userRepository.save(recipient);
            userRepository.flush();

            // Check and award badges (this should be done after saving users)
            try {
                badgeService.checkAndAwardBadges(sender);
                badgeService.checkAndAwardBadges(recipient);
            } catch (Exception badgeException) {
                // Log badge error but don't fail the payment
                System.err.println("Badge awarding failed: " + badgeException.getMessage());
            }

            return new PaymentResponse("Payment successful", transactionReference, true);

        } catch (Exception e) {
            return new PaymentResponse("Payment failed: " + e.getMessage(), null, false);
        }
    }

    public List<TransactionResponse> getUserTransactions(TransactionCategory category, TransactionType type) {
        User user = userService.getCurrentUser();
        List<Transaction> transactions;

        if (category != null && type != null) {
            transactions = transactionRepository.findByUserAndTypeAndCategoryOrderByCreatedAtDesc(user, type, category);
        } else if (category != null) {
            transactions = transactionRepository.findByUserAndCategoryOrderByCreatedAtDesc(user, category);
        } else if (type != null) {
            transactions = transactionRepository.findByUserAndTypeOrderByCreatedAtDesc(user, type);
        } else {
            transactions = transactionRepository.findByUserOrderByCreatedAtDesc(user);
        }

        List<TransactionResponse> responses = new ArrayList<>();
        for (Transaction transaction : transactions) {
            TransactionResponse response = new TransactionResponse();
            response.setId(transaction.getId());
            response.setUserId(transaction.getUser().getId());
            response.setUserDisplayName(transaction.getUser().getDisplayName());
            
            if (transaction.getRelatedUser() != null) {
                response.setRelatedUserId(transaction.getRelatedUser().getId());
                response.setRelatedUserDisplayName(transaction.getRelatedUser().getDisplayName());
            }
            
            response.setAmount(transaction.getAmount());
            response.setType(transaction.getType());
            response.setStatus(transaction.getStatus());
            response.setNotes(transaction.getNotes());
            response.setCategory(transaction.getCategory());
            response.setTransactionReference(transaction.getTransactionReference());
            response.setCreatedAt(transaction.getCreatedAt());
            
            responses.add(response);
        }

        return responses;
    }

    public TransactionResponse getTransactionByReference(String transactionReference) {
        User user = userService.getCurrentUser();
        Transaction transaction = transactionRepository.findByTransactionReference(transactionReference)
                .orElseThrow(() -> new RuntimeException("Transaction not found"));

        // Verify user has access to this transaction
        if (!transaction.getUser().getId().equals(user.getId()) && 
            (transaction.getRelatedUser() == null || !transaction.getRelatedUser().getId().equals(user.getId()))) {
            throw new RuntimeException("Access denied to this transaction");
        }

        TransactionResponse response = new TransactionResponse();
        response.setId(transaction.getId());
        response.setUserId(transaction.getUser().getId());
        response.setUserDisplayName(transaction.getUser().getDisplayName());
        
        if (transaction.getRelatedUser() != null) {
            response.setRelatedUserId(transaction.getRelatedUser().getId());
            response.setRelatedUserDisplayName(transaction.getRelatedUser().getDisplayName());
        }
        
        response.setAmount(transaction.getAmount());
        response.setType(transaction.getType());
        response.setStatus(transaction.getStatus());
        response.setNotes(transaction.getNotes());
        response.setCategory(transaction.getCategory());
        response.setTransactionReference(transaction.getTransactionReference());
        response.setCreatedAt(transaction.getCreatedAt());

        return response;
    }
}