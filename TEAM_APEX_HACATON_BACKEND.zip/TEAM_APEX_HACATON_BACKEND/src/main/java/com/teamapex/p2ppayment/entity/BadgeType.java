package com.teamapex.p2ppayment.entity;

public enum BadgeType {
    ACHIEVEMENT,
    MILESTONE,
    STREAK,
    SPECIAL
}