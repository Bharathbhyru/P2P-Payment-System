package com.teamapex.p2ppayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P2pPaymentSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(P2pPaymentSystemApplication.class, args);
    }

}