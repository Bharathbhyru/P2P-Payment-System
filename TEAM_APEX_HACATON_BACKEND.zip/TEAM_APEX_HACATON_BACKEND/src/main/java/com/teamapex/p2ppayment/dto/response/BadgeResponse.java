package com.teamapex.p2ppayment.dto.response;

import com.teamapex.p2ppayment.entity.BadgeType;

import java.time.LocalDateTime;

public class BadgeResponse {
    
    private Long id;
    private String name;
    private String description;
    private String iconUrl;
    private Integer pointsRequired;
    private BadgeType type;
    private LocalDateTime earnedAt;
    
    // Constructors
    public BadgeResponse() {}
    
    public BadgeResponse(Long id, String name, String description, String iconUrl, 
                        Integer pointsRequired, BadgeType type, LocalDateTime earnedAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.iconUrl = iconUrl;
        this.pointsRequired = pointsRequired;
        this.type = type;
        this.earnedAt = earnedAt;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getIconUrl() {
        return iconUrl;
    }
    
    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }
    
    public Integer getPointsRequired() {
        return pointsRequired;
    }
    
    public void setPointsRequired(Integer pointsRequired) {
        this.pointsRequired = pointsRequired;
    }
    
    public BadgeType getType() {
        return type;
    }
    
    public void setType(BadgeType type) {
        this.type = type;
    }
    
    public LocalDateTime getEarnedAt() {
        return earnedAt;
    }
    
    public void setEarnedAt(LocalDateTime earnedAt) {
        this.earnedAt = earnedAt;
    }
}