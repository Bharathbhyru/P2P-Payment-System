package com.teamapex.p2ppayment.entity;

public enum TransactionStatus {
    PENDING,
    COMPLETED,
    FAILED,
    CANCELLED
}