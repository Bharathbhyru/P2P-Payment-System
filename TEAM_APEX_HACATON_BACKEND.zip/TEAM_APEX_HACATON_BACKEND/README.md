# P2P Payment System Backend

A Spring Boot backend application for a Peer-to-Peer payment system with JWT authentication, transaction management, and gamification features.

## Features

- **User Authentication**: JWT-based authentication with secure login/registration
- **P2P Payments**: Send and receive money between users with transaction integrity
- **Transaction History**: Complete transaction tracking with filtering options
- **Gamification**: Badge system with points and achievements
- **Profile Management**: User profile updates and management
- **Security**: All endpoints (except auth) protected with JWT tokens

## Technology Stack

- **Framework**: Spring Boot 3.1.5
- **Security**: Spring Security with JWT
- **Database**: H2 (in-memory) / MySQL support
- **ORM**: Hibernate/JPA
- **Validation**: Bean Validation
- **Build Tool**: Maven

## Getting Started

### Prerequisites

- Java 17 or higher
- Maven 3.6 or higher

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd backend
```

2. Build the project
```bash
mvn clean install
```

3. Run the application
```bash
mvn spring-boot:run
```

The application will start on `http://localhost:8080`

### Database

The application uses H2 in-memory database by default. You can access the H2 console at:
- URL: `http://localhost:8080/h2-console`
- JDBC URL: `jdbc:h2:mem:testdb`
- Username: `sa`
- Password: `password`

## API Endpoints

### Authentication Endpoints (Public)

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "password": "password123",
  "displayName": "John Doe",
  "email": "john@example.com",
  "phoneNumber": "1234567890",
  "profilePictureUrl": "https://example.com/avatar.jpg"
}
```

#### Login User
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "johndoe",
  "password": "password123"
}
```

### Protected Endpoints (Require JWT Token)

**Authentication Header Required:**
```
Authorization: Bearer <your-jwt-token>
```

#### Get User Profile
```http
GET /api/users/profile
```

#### Update User Profile
```http
PUT /api/users/profile
Content-Type: application/json

{
  "displayName": "John Updated",
  "profilePictureUrl": "https://example.com/new-avatar.jpg"
}
```

#### Search Users
```http
GET /api/users/search?query=john
```

#### Send Payment
```http
POST /api/payments
Content-Type: application/json

{
  "recipientId": 2,
  "amount": 100.50,
  "notes": "Payment for dinner",
  "category": "FOOD_DINING"
}
```

#### Get Transactions
```http
GET /api/transactions
GET /api/transactions?category=FOOD_DINING
GET /api/transactions?type=DEBIT
GET /api/transactions?category=FOOD_DINING&type=CREDIT
```

#### Get Transaction by Reference
```http
GET /api/transactions/{transactionReference}
```

#### Get User Badges
```http
GET /api/badges
```

## Data Models

### User
- ID, Username, Password (hashed)
- Display Name, Email, Phone Number
- Profile Picture URL
- Current Balance, Total Points
- Created/Updated timestamps

### Transaction
- ID, User, Related User
- Amount, Type (DEBIT/CREDIT), Status
- Notes, Category, Transaction Reference
- Created timestamp

### Badge
- ID, Name, Description
- Icon URL, Points Required, Type
- Created timestamp

### Transaction Categories
- FOOD_DINING
- TRANSPORT
- ENTERTAINMENT
- BILLS_UTILITIES
- SHOPPING
- HEALTHCARE
- EDUCATION
- TRAVEL
- GROCERIES
- FRIENDS_FAMILY
- BUSINESS
- OTHERS

## Security Features

1. **Password Encryption**: BCrypt hashing
2. **JWT Authentication**: Secure token-based authentication
3. **CORS Support**: Cross-origin resource sharing enabled
4. **Input Validation**: Bean validation on all endpoints
5. **Transaction Integrity**: Atomic operations for money transfers

## Transaction Flow

When a payment is made:

1. **Validation**: Check sender balance, recipient exists, valid amount
2. **Balance Update**: Deduct from sender, add to recipient
3. **Transaction Creation**: Create two transaction records:
   - Debit transaction for sender
   - Credit transaction for recipient
4. **Points Award**: Add points to both users
5. **Badge Check**: Check and award new badges
6. **Atomic Operation**: All operations in single transaction

## Gamification Features

### Default Badges
- **Welcome**: Awarded on registration (0 points)
- **First Payment**: First payment made (10 points)
- **Payment Pro**: 10 payments made (100 points)
- **Transaction Master**: 50 payments made (500 points)
- **Streak Starter**: 3 consecutive days of payments (30 points)
- **Social Butterfly**: Send money to 5 different people (50 points)

## Error Handling

The application includes comprehensive error handling:
- Input validation errors
- Authentication/Authorization errors
- Business logic errors
- Generic exception handling

## Configuration

Key configuration in `application.properties`:
```properties
# JWT Settings
app.jwt.secret=mySecretKey123456789abcdefghijklmnopqrstuvwxyz
app.jwt.expiration=86400000

# Database Settings
spring.datasource.url=jdbc:h2:mem:testdb
spring.jpa.hibernate.ddl-auto=create-drop

# Server Settings
server.port=8080
```

## Testing

You can test the API using tools like:
- Postman
- curl
- Any REST client

### Sample Flow

1. Register a new user
2. Login to get JWT token
3. Use token to access protected endpoints
4. Create transactions between users
5. Check transaction history and badges

## Production Considerations

For production deployment:

1. **Database**: Switch to MySQL/PostgreSQL
2. **Security**: Use environment variables for secrets
3. **Logging**: Configure proper logging levels
4. **Monitoring**: Add health checks and metrics
5. **Caching**: Implement Redis for JWT blacklisting
6. **Rate Limiting**: Add API rate limiting
7. **Documentation**: Add Swagger/OpenAPI documentation

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request