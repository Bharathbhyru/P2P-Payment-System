# 🧪 Postman API Testing Guide - P2P Payment System

## 📋 Complete Testing Flow: Signup → Login → Transactions

### 🔧 **Prerequisites**
1. Make sure the Spring Boot application is running on `http://localhost:8080`
2. Open Postman
3. Create a new Collection called "P2P Payment System"

---

## 🚀 **Step-by-Step API Testing**

### **Step 1: Register First User**

**Method:** `POST`  
**URL:** `http://localhost:8080/api/auth/register`  
**Headers:**
```
Content-Type: application/json
```

**Body (JSON):**
```json
{
  "username": "alice_smith",
  "password": "password123",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg"
}
```

**Expected Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "type": "Bearer",
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "message": "User registered successfully!"
}
```

**💡 Action:** Copy the `token` value for next requests

---

### **Step 2: Register Second User (for P2P testing)**

**Method:** `POST`  
**URL:** `http://localhost:8080/api/auth/register`  
**Headers:**
```
Content-Type: application/json
```

**Body (JSON):**
```json
{
  "username": "bob_jones",
  "password": "password123",
  "displayName": "Bob Jones", 
  "email": "bob@example.com",
  "phoneNumber": "9876543211",
  "profilePictureUrl": "https://example.com/bob.jpg"
}
```

**💡 Action:** Note the user ID from response (will be `2`)

---

### **Step 3: Login with First User**

**Method:** `POST`  
**URL:** `http://localhost:8080/api/auth/login`  
**Headers:**
```
Content-Type: application/json
```

**Body (JSON):**
```json
{
  "username": "alice_smith",
  "password": "password123"
}
```

**Expected Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "type": "Bearer", 
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "message": "User logged in successfully!"
}
```

---

### **Step 4: Get User Profile**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/users/profile`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
  "id": 1,
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg",
  "balance": 1000.00,
  "totalPoints": 10,
  "createdAt": "2025-10-09T11:22:52.302065"
}
```

**💡 Note:** Each new user starts with ₹1000 balance and 10 points

---

### **Step 5: Check Initial Badges**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/badges`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
[
  {
    "id": 1,
    "name": "Welcome",
    "description": "Welcome to P2P Payment System!",
    "iconUrl": "🎉",
    "pointsRequired": 0,
    "type": "MILESTONE",
    "earnedAt": "2025-10-09T11:22:52.311541"
  }
]
```

---

### **Step 6: Search for Users (Find Bob)**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/users/search?query=bob`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
[
  {
    "id": 2,
    "username": "bob_jones",
    "displayName": "Bob Jones",
    "email": "bob@example.com",
    "phoneNumber": "9876543211",
    "profilePictureUrl": "https://example.com/bob.jpg",
    "balance": null,
    "totalPoints": null,
    "createdAt": "2025-10-09T11:23:15.123456"
  }
]
```

**💡 Note:** Balance and points are hidden in search for privacy

---

### **Step 7: Send Money to Bob (P2P Payment)**

**Method:** `POST`  
**URL:** `http://localhost:8080/api/payments`  
**Headers:**
```
Content-Type: application/json
Authorization: Bearer {{token}}
```

**Body (JSON):**
```json
{
  "recipientId": 2,
  "amount": 250.50,
  "notes": "Payment for dinner last night",
  "category": "FOOD_DINING"
}
```

**Expected Response:**
```json
{
  "message": "Payment successful",
  "transactionReference": "TXN1A2B3C4D5E6F7",
  "success": true
}
```

**💡 Action:** Copy the `transactionReference` for tracking

---

### **Step 8: Check Transaction History**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/transactions`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
[
  {
    "id": 1,
    "userId": 1,
    "userDisplayName": "Alice Smith",
    "relatedUserId": 2,
    "relatedUserDisplayName": "Bob Jones",
    "amount": 250.50,
    "type": "DEBIT",
    "status": "COMPLETED",
    "notes": "Payment for dinner last night",
    "category": "FOOD_DINING",
    "transactionReference": "TXN1A2B3C4D5E6F7",
    "createdAt": "2025-10-09T11:25:30.123456"
  }
]
```

---

### **Step 9: Get Transaction by Reference**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/transactions/TXN1A2B3C4D5E6F7`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
  "id": 1,
  "userId": 1,
  "userDisplayName": "Alice Smith",
  "relatedUserId": 2,
  "relatedUserDisplayName": "Bob Jones",
  "amount": 250.50,
  "type": "DEBIT",
  "status": "COMPLETED",
  "notes": "Payment for dinner last night",
  "category": "FOOD_DINING",
  "transactionReference": "TXN1A2B3C4D5E6F7",
  "createdAt": "2025-10-09T11:25:30.123456"
}
```

---

### **Step 10: Filter Transactions by Category**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/transactions?category=FOOD_DINING`  
**Headers:**
```
Authorization: Bearer {{token}}
```

---

### **Step 11: Filter Transactions by Type**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/transactions?type=DEBIT`  
**Headers:**
```
Authorization: Bearer {{token}}
```

---

### **Step 12: Check Updated Profile (After Transaction)**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/users/profile`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
{
  "id": 1,
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg",
  "balance": 749.50,
  "totalPoints": 11,
  "createdAt": "2025-10-09T11:22:52.302065"
}
```

**💡 Note:** Balance reduced by ₹250.50, points increased by 1

---

### **Step 13: Check New Badges (After First Payment)**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/badges`  
**Headers:**
```
Authorization: Bearer {{token}}
```

**Expected Response:**
```json
[
  {
    "id": 1,
    "name": "Welcome",
    "description": "Welcome to P2P Payment System!",
    "iconUrl": "🎉",
    "pointsRequired": 0,
    "type": "MILESTONE",
    "earnedAt": "2025-10-09T11:22:52.311541"
  },
  {
    "id": 2,
    "name": "First Payment",
    "description": "Made your first payment",
    "iconUrl": "💳",
    "pointsRequired": 10,
    "type": "ACHIEVEMENT",
    "earnedAt": "2025-10-09T11:25:30.456789"
  }
]
```

---

### **Step 14: Update Profile**

**Method:** `PUT`  
**URL:** `http://localhost:8080/api/users/profile`  
**Headers:**
```
Content-Type: application/json
Authorization: Bearer {{token}}
```

**Body (JSON):**
```json
{
  "displayName": "Alice Smith Updated",
  "profilePictureUrl": "https://example.com/alice-new.jpg"
}
```

---

## 🔍 **Testing Bob's Perspective (Recipient)**

### **Step 15: Login as Bob**

**Method:** `POST`  
**URL:** `http://localhost:8080/api/auth/login`  
**Headers:**
```
Content-Type: application/json
```

**Body (JSON):**
```json
{
  "username": "bob_jones",
  "password": "password123"
}
```

### **Step 16: Check Bob's Transaction History**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/transactions`  
**Headers:**
```
Authorization: Bearer {{bob_token}}
```

**Expected Response:**
```json
[
  {
    "id": 2,
    "userId": 2,
    "userDisplayName": "Bob Jones",
    "relatedUserId": 1,
    "relatedUserDisplayName": "Alice Smith",
    "amount": 250.50,
    "type": "CREDIT",
    "status": "COMPLETED",
    "notes": "Payment for dinner last night",
    "category": "FOOD_DINING",
    "transactionReference": "TXN1A2B3C4D5E6F7",
    "createdAt": "2025-10-09T11:25:30.123456"
  }
]
```

### **Step 17: Check Bob's Updated Balance**

**Method:** `GET`  
**URL:** `http://localhost:8080/api/users/profile`  
**Headers:**
```
Authorization: Bearer {{bob_token}}
```

**Expected Response:**
```json
{
  "id": 2,
  "username": "bob_jones",
  "displayName": "Bob Jones",
  "email": "bob@example.com",
  "phoneNumber": "9876543211",
  "profilePictureUrl": "https://example.com/bob.jpg",
  "balance": 1250.50,
  "totalPoints": 11,
  "createdAt": "2025-10-09T11:23:15.123456"
}
```

**💡 Note:** Bob's balance increased by ₹250.50 (1000 + 250.50 = 1250.50)

---

## 📝 **Transaction Categories Available**

Use these in the `category` field:
- `FOOD_DINING`
- `TRANSPORT`
- `ENTERTAINMENT`
- `BILLS_UTILITIES`
- `SHOPPING`
- `HEALTHCARE`
- `EDUCATION`
- `TRAVEL`
- `GROCERIES`
- `FRIENDS_FAMILY`
- `BUSINESS`
- `OTHERS`

---

## 🚨 **Error Testing Scenarios**

### **Test Insufficient Balance**
```json
{
  "recipientId": 2,
  "amount": 2000.00,
  "notes": "Large payment",
  "category": "OTHERS"
}
```
**Expected:** `{"message": "Insufficient balance", "success": false}`

### **Test Invalid Recipient**
```json
{
  "recipientId": 999,
  "amount": 100.00,
  "notes": "Invalid user",
  "category": "OTHERS"
}
```
**Expected:** `{"message": "Payment failed: User not found with id: 999", "success": false}`

### **Test Self Payment**
```json
{
  "recipientId": 1,
  "amount": 100.00,
  "notes": "Self payment",
  "category": "OTHERS"
}
```
**Expected:** `{"message": "Cannot send money to yourself", "success": false}`

---

## 🎯 **Key Points to Verify**

1. **✅ Transaction Integrity**: Each payment creates 2 transactions (DEBIT + CREDIT)
2. **✅ Balance Updates**: Sender balance decreases, receiver balance increases
3. **✅ Points System**: Both users get +1 point per transaction
4. **✅ Badge System**: Welcome badge on signup, First Payment badge after first transaction
5. **✅ JWT Security**: All endpoints except auth require valid token
6. **✅ Unique References**: Each payment gets unique transaction reference
7. **✅ Category Filtering**: Can filter transactions by category and type

---

## 🔧 **Postman Environment Variables**

Set these in Postman Environment:
- `baseUrl`: `http://localhost:8080`
- `alice_token`: `{{token from Alice login}}`
- `bob_token`: `{{token from Bob login}}`

---

**🎉 Happy Testing! Your P2P Payment System is working perfectly!**