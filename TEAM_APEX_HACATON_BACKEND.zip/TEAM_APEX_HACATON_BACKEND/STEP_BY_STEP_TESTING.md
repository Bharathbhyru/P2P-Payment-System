# 🚀 Complete Postman API Testing - Step by Step

## Prerequisites
- Spring Boot app running on `http://localhost:8080`
- Postman application open
- Create new Collection: "P2P Payment System"

---

## 📋 **STEP 1: Register First User (Alice)**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/auth/register`

### Headers:
```
Content-Type: application/json
```

### Body (Raw JSON):
```json
{
  "username": "alice_smith",
  "password": "password123",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg"
}
```

### Expected Response (200 OK):
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzEyMywiZXhwIjoxNzI4NTM5NTIzfQ.abc123def456ghi789",
  "type": "Bearer",
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "message": "User registered successfully!"
}
```

### 📝 Action Required:
**COPY the `token` value - you'll need it for authenticated requests!**

---

## 📋 **STEP 2: Register Second User (Bob)**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/auth/register`

### Headers:
```
Content-Type: application/json
```

### Body (Raw JSON):
```json
{
  "username": "bob_jones",
  "password": "password123",
  "displayName": "Bob Jones",
  "email": "bob@example.com",
  "phoneNumber": "9876543211",
  "profilePictureUrl": "https://example.com/bob.jpg"
}
```

### Expected Response (200 OK):
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJib2Jfam9uZXMiLCJpYXQiOjE3Mjg0NTMxNTYsImV4cCI6MTcyODUzOTU1Nn0.xyz789abc123def456",
  "type": "Bearer",
  "username": "bob_jones",
  "displayName": "Bob Jones",
  "message": "User registered successfully!"
}
```

### 📝 Action Required:
**Note: Bob's user ID will be `2` (we'll use this for payments)**

---

## 📋 **STEP 3: Login as Alice**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/auth/login`

### Headers:
```
Content-Type: application/json
```

### Body (Raw JSON):
```json
{
  "username": "alice_smith",
  "password": "password123"
}
```

### Expected Response (200 OK):
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789",
  "type": "Bearer",
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "message": "User logged in successfully!"
}
```

---

## 📋 **STEP 4: Get Alice's Profile**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/users/profile`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
{
  "id": 1,
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg",
  "balance": 1000.00,
  "totalPoints": 10,
  "createdAt": "2025-10-09T11:30:23.123456"
}
```

### 📝 Key Points:
- ✅ Starting balance: ₹1000
- ✅ Starting points: 10
- ✅ User ID: 1

---

## 📋 **STEP 5: Check Alice's Initial Badges**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/badges`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
[
  {
    "id": 1,
    "name": "Welcome",
    "description": "Welcome to P2P Payment System!",
    "iconUrl": "🎉",
    "pointsRequired": 0,
    "type": "MILESTONE",
    "earnedAt": "2025-10-09T11:30:23.456789"
  }
]
```

### 📝 Key Points:
- ✅ New users automatically get "Welcome" badge

---

## 📋 **STEP 6: Search for Bob**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/users/search?query=bob`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
[
  {
    "id": 2,
    "username": "bob_jones",
    "displayName": "Bob Jones",
    "email": "bob@example.com",
    "phoneNumber": "9876543211",
    "profilePictureUrl": "https://example.com/bob.jpg",
    "balance": null,
    "totalPoints": null,
    "createdAt": "2025-10-09T11:30:45.789012"
  }
]
```

### 📝 Key Points:
- ✅ Found Bob with ID: 2
- ✅ Balance/Points hidden for privacy

---

## 📋 **STEP 7: Send Money to Bob (₹250.50)**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/payments`

### Headers:
```
Content-Type: application/json
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body (Raw JSON):
```json
{
  "recipientId": 2,
  "amount": 250.50,
  "notes": "Payment for dinner last night",
  "category": "FOOD_DINING"
}
```

### Expected Response (200 OK):
```json
{
  "message": "Payment successful",
  "transactionReference": "TXN1A2B3C4D5E6F7",
  "success": true
}
```

### 📝 Action Required:
**COPY the `transactionReference` - you'll use it to track this payment!**

---

## 📋 **STEP 8: Check Alice's Transaction History**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/transactions`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
[
  {
    "id": 1,
    "userId": 1,
    "userDisplayName": "Alice Smith",
    "relatedUserId": 2,
    "relatedUserDisplayName": "Bob Jones",
    "amount": 250.50,
    "type": "DEBIT",
    "status": "COMPLETED",
    "notes": "Payment for dinner last night",
    "category": "FOOD_DINING",
    "transactionReference": "TXN1A2B3C4D5E6F7",
    "createdAt": "2025-10-09T11:31:15.123456"
  }
]
```

### 📝 Key Points:
- ✅ Type: DEBIT (money went out from Alice)
- ✅ Status: COMPLETED
- ✅ Same transaction reference

---

## 📋 **STEP 9: Check Alice's Updated Balance**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/users/profile`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
{
  "id": 1,
  "username": "alice_smith",
  "displayName": "Alice Smith",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice.jpg",
  "balance": 749.50,
  "totalPoints": 11,
  "createdAt": "2025-10-09T11:30:23.123456"
}
```

### 📝 Key Points:
- ✅ Balance: ₹749.50 (was ₹1000 - ₹250.50)
- ✅ Points: 11 (was 10 + 1 for transaction)

---

## 📋 **STEP 10: Check Alice's New Badges**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/badges`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
[
  {
    "id": 1,
    "name": "Welcome",
    "description": "Welcome to P2P Payment System!",
    "iconUrl": "🎉",
    "pointsRequired": 0,
    "type": "MILESTONE",
    "earnedAt": "2025-10-09T11:30:23.456789"
  },
  {
    "id": 2,
    "name": "First Payment",
    "description": "Made your first payment",
    "iconUrl": "💳",
    "pointsRequired": 10,
    "type": "ACHIEVEMENT",
    "earnedAt": "2025-10-09T11:31:15.789012"
  }
]
```

### 📝 Key Points:
- ✅ Alice earned "First Payment" badge after sending money!

---

## 📋 **STEP 11: Get Transaction by Reference**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/transactions/TXN1A2B3C4D5E6F7`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
{
  "id": 1,
  "userId": 1,
  "userDisplayName": "Alice Smith",
  "relatedUserId": 2,
  "relatedUserDisplayName": "Bob Jones",
  "amount": 250.50,
  "type": "DEBIT",
  "status": "COMPLETED",
  "notes": "Payment for dinner last night",
  "category": "FOOD_DINING",
  "transactionReference": "TXN1A2B3C4D5E6F7",
  "createdAt": "2025-10-09T11:31:15.123456"
}
```

---

## 📋 **STEP 12: Login as Bob (Check Recipient Side)**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/auth/login`

### Headers:
```
Content-Type: application/json
```

### Body (Raw JSON):
```json
{
  "username": "bob_jones",
  "password": "password123"
}
```

### Expected Response (200 OK):
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJib2Jfam9uZXMiLCJpYXQiOjE3Mjg0NTM0MDAsImV4cCI6MTcyODUzOTgwMH0.bobtoken123456789",
  "type": "Bearer",
  "username": "bob_jones",
  "displayName": "Bob Jones",
  "message": "User logged in successfully!"
}
```

### 📝 Action Required:
**COPY Bob's token for next requests!**

---

## 📋 **STEP 13: Check Bob's Profile (Recipient)**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/users/profile`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJib2Jfam9uZXMiLCJpYXQiOjE3Mjg0NTM0MDAsImV4cCI6MTcyODUzOTgwMH0.bobtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
{
  "id": 2,
  "username": "bob_jones",
  "displayName": "Bob Jones",
  "email": "bob@example.com",
  "phoneNumber": "9876543211",
  "profilePictureUrl": "https://example.com/bob.jpg",
  "balance": 1250.50,
  "totalPoints": 11,
  "createdAt": "2025-10-09T11:30:45.789012"
}
```

### 📝 Key Points:
- ✅ Balance: ₹1250.50 (was ₹1000 + ₹250.50)
- ✅ Points: 11 (was 10 + 1 for receiving payment)

---

## 📋 **STEP 14: Check Bob's Transaction History**

### Request Details:
- **Method:** `GET`
- **URL:** `http://localhost:8080/api/transactions`

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJib2Jfam9uZXMiLCJpYXQiOjE3Mjg0NTM0MDAsImV4cCI6MTcyODUzOTgwMH0.bobtoken123456789
```

### Body:
```
No body required for GET request
```

### Expected Response (200 OK):
```json
[
  {
    "id": 2,
    "userId": 2,
    "userDisplayName": "Bob Jones",
    "relatedUserId": 1,
    "relatedUserDisplayName": "Alice Smith",
    "amount": 250.50,
    "type": "CREDIT",
    "status": "COMPLETED",
    "notes": "Payment for dinner last night",
    "category": "FOOD_DINING",
    "transactionReference": "TXN1A2B3C4D5E6F7",
    "createdAt": "2025-10-09T11:31:15.123456"
  }
]
```

### 📝 Key Points:
- ✅ Type: CREDIT (money came in to Bob)
- ✅ Same transaction reference as Alice's DEBIT
- ✅ Transaction integrity maintained!

---

## 📋 **STEP 15: Update Profile (Alice)**

### Request Details:
- **Method:** `PUT`
- **URL:** `http://localhost:8080/api/users/profile`

### Headers:
```
Content-Type: application/json
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body (Raw JSON):
```json
{
  "displayName": "Alice Smith Updated",
  "profilePictureUrl": "https://example.com/alice-new.jpg"
}
```

### Expected Response (200 OK):
```json
{
  "id": 1,
  "username": "alice_smith",
  "displayName": "Alice Smith Updated",
  "email": "alice@example.com",
  "phoneNumber": "9876543210",
  "profilePictureUrl": "https://example.com/alice-new.jpg",
  "balance": 749.50,
  "totalPoints": 11,
  "createdAt": "2025-10-09T11:30:23.123456"
}
```

---

## 🚨 **ERROR TESTING**

### **Test 1: Insufficient Balance**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/payments`

### Headers:
```
Content-Type: application/json
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body (Raw JSON):
```json
{
  "recipientId": 2,
  "amount": 2000.00,
  "notes": "Large payment test",
  "category": "OTHERS"
}
```

### Expected Response (400 Bad Request):
```json
{
  "message": "Insufficient balance",
  "transactionReference": null,
  "success": false
}
```

---

### **Test 2: Self Payment**

### Request Details:
- **Method:** `POST`
- **URL:** `http://localhost:8080/api/payments`

### Headers:
```
Content-Type: application/json
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbGljZV9zbWl0aCIsImlhdCI6MTcyODQ1MzIwMCwiZXhwIjoxNzI4NTM5NjAwfQ.newtoken123456789
```

### Body (Raw JSON):
```json
{
  "recipientId": 1,
  "amount": 100.00,
  "notes": "Self payment test",
  "category": "OTHERS"
}
```

### Expected Response (400 Bad Request):
```json
{
  "message": "Cannot send money to yourself",
  "transactionReference": null,
  "success": false
}
```

---

## 🎯 **TRANSACTION CATEGORIES**

Use these exact values in the `category` field:
- `FOOD_DINING`
- `TRANSPORT`
- `ENTERTAINMENT`
- `BILLS_UTILITIES`
- `SHOPPING`
- `HEALTHCARE`
- `EDUCATION`
- `TRAVEL`
- `GROCERIES`
- `FRIENDS_FAMILY`
- `BUSINESS`
- `OTHERS`

---

## ✅ **VERIFICATION CHECKLIST**

After completing all steps, verify:

- [ ] ✅ Alice balance: ₹749.50 (₹1000 - ₹250.50)
- [ ] ✅ Bob balance: ₹1250.50 (₹1000 + ₹250.50)
- [ ] ✅ Both users have 11 points (10 + 1)
- [ ] ✅ Alice has 2 badges (Welcome + First Payment)
- [ ] ✅ Bob has 1 badge (Welcome)
- [ ] ✅ Same transaction reference for both users
- [ ] ✅ Alice sees DEBIT, Bob sees CREDIT
- [ ] ✅ All authenticated endpoints require valid JWT
- [ ] ✅ Error handling works correctly

---

## 🎉 **SUCCESS!**

Your P2P Payment System is working perfectly! The transaction integrity is maintained with dual entries, balances are updated correctly, and the gamification system is functioning as expected.

**You're ready for your hackathon demo!** 🚀